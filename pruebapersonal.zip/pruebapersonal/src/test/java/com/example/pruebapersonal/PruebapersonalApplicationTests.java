package com.example.pruebapersonal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebapersonalApplicationTests {

	@Test
	void contextLoads() {
	}

}
